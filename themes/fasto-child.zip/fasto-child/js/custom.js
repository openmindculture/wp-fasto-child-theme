jQuery(".search-trigger").on( "click", function() {
    /* focus on the search input form field */
    document.getElementById('s').focus();
});